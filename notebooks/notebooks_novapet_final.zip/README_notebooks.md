# Notebooks finales — Proyecto NovaPet

Esta carpeta contiene los notebooks limpios y ordenados para evidenciar reproducibilidad técnica del proyecto.

## Orden recomendado de ejecución

1. `01_preparacion_datos.ipynb`  
   Construye el dataset supervisado desde el Kardex.

2. `02_entrenamiento_modelos.ipynb`  
   Entrena y compara Baseline, Random Forest y XGBoost. Genera `metricas_finales.csv` y el modelo `.pkl`.

3. `03_validacion_walkforward.ipynb`  
   Genera evidencia de validación hold-out temporal y walk-forward validation.

4. `04_interpretabilidad_shap.ipynb`  
   Genera evidencias de interpretabilidad del Random Forest mediante SHAP.

## Archivo de datos esperado

Colocar el Kardex en:

```text
data/kardex_actualizado_febrero_2026.xlsx
```

## Salidas esperadas

Los notebooks generan archivos en:

```text
resultados/
models/
```

## Nota metodológica

El prototipo final usa el baseline de promedio móvil de 4 semanas como motor principal, debido a su mejor desempeño global en validación temporal. Random Forest se mantiene como referencia experimental secundaria para comparación e interpretabilidad.
